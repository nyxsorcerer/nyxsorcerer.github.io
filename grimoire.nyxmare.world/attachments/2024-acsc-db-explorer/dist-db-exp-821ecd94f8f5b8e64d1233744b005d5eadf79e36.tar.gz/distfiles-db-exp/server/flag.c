#include <stdio.h>

int main(void) {
    printf("ACSC{test_flag}");
}