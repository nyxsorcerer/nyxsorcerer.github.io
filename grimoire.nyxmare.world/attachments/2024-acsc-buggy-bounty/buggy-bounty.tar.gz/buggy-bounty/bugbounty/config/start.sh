#!/bin/bash
node /app/index.js